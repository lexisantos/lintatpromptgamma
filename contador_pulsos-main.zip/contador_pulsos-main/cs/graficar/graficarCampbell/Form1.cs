﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Threading;

namespace graficarCampbell
{
    public partial class Form1 : Form
    {
        private const int Nvariables = 1;
        private const int LenStringDato = 44;
        private double Promediado = 0.0;
        private double faltan = 0.0;
        private int Promediando = 0;
        private long NumeroAPromediar = 1;
        private string[] Nnombres = { "Pulsos", "Fluctuación", "Logaritmico", "Tasa" };
        private string Nombre = "Medidor por Fluctuación";
        private Color[] PeroMiraQueColores = { Color.Red, Color.Blue, Color.Green, Color.Orange, Color.Red, Color.Blue, Color.Green, Color.Orange };
        private bool Registrar;

        public Form1()
        {
            InitializeComponent();
            saveFileDialog1.FileName = "";
            _.Dock = DockStyle.Right;
            this.MinimumSize = this.Size;
            this.Text = Nombre;
            Registrar = false;
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.Columns.Add("Variable", listView1.Width / 2);
            listView1.Columns.Add("Valor", listView1.Width / 2);
            listView1.Scrollable = false;

            for (int i = 0; i < Nvariables; i++)
            {
                string[] items = new string[3];
                items[0] = Nnombres[i];
                items[1] = "0";
                ListViewItem lvi = new ListViewItem(items);
                listView1.Items.Add(lvi);
            }
            string[] modo = new string[3];
            modo[0] = "Modo";
            modo[1] = "";
            listView1.Items.Add(new ListViewItem(modo));

            string[] dbg = new string[3];
            dbg[0] = "Debug";
            dbg[1] = "0x00";
            listView1.Items.Add(new ListViewItem(dbg));


            listView1.Enabled = false;
            Chart[] graficos = getGraficos();
            for (int i = 0; i < graficos.Length; i++)
            {
                configChart(graficos[i], PeroMiraQueColores[i]);
            }
            ponerNombres(graficos, Nnombres);
            clearGraficos(graficos);
            button2_Click(this, null);
            Form1_Resize(this, null);
            comboBox2.SelectedIndex = 0;
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            Chart[] graficos = new Chart[4];
            graficos[0] = chart1;
            graficos[1] = chart2;
            graficos[2] = chart3;
            graficos[3] = chart4;
            chart5.Dock = DockStyle.Fill;
            chart6.Dock = DockStyle.Fill;
            chart7.Dock = DockStyle.Fill;
            chart8.Dock = DockStyle.Fill;

            groupBox2.Left = groupBox1.Left;
            int wg = (groupBox1.Width > groupBox2.Width) ? groupBox1.Width : groupBox2.Width;
            int margen = 40;
            _.Width = this.Width - wg - margen;
            for (int i = 0; i < graficos.Length; i++)
            {
                graficos[i].Anchor = AnchorStyles.Left;
                //graficos[i].Width = flowLayoutPanel1.Width - margen/4;
                //graficos[i].Height = flowLayoutPanel1.Height / 4 * 90/100;
            }
            for (int i = 0; i < _.TabPages.Count; i++)
            {
                _.TabPages[i].BackColor = SystemColors.Control;
            }


        }

        private void configChart(Chart c, Color linea)
        {
            if (c.Series.Count <= 0)
            {
                c.Series.Add(new Series());
            }
            if (c.Legends.Count > 0)
            {
                c.Legends[0].BackColor = Color.Transparent;
            }
            c.Series[0].ChartType = SeriesChartType.Line;
            c.Series[0].Color = linea;
            c.Series[0].IsVisibleInLegend = false;
            c.Series[0].BorderWidth = 1;
            c.BackColor = Color.Transparent;
            c.ChartAreas[0].BackColor = Color.Transparent;     
            c.ChartAreas[0].AxisX.MajorGrid.Enabled = true;
            c.ChartAreas[0].AxisX.MinorGrid.LineDashStyle = ChartDashStyle.Dash;
            c.ChartAreas[0].AxisX.MinorGrid.Enabled = true;
            c.ChartAreas[0].AxisY.MajorGrid.Enabled = true;
            c.ChartAreas[0].AxisY.MinorGrid.LineDashStyle = ChartDashStyle.Dash;
            c.Update();
        }

        private Chart[] getGraficos()
        {
            Chart[] ret = new Chart[8];
            ret[0] = chart1;
            ret[1] = chart2;
            ret[2] = chart3;
            ret[3] = chart4;
            ret[4] = chart5;
            ret[5] = chart6;
            ret[6] = chart7;
            ret[7] = chart8;
            return ret;
        }

        private void clearGraficos(Chart[] graficos)
        {
            for (int i = 0; i < graficos.Length; i++)
            {
                graficos[i].Series[0].Points.Clear();
                graficos[i].Series[0].Points.Invalidate();
                graficos[i].ChartAreas[0].RecalculateAxesScale();
                graficos[i].Update();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!serialPort1.IsOpen)
            {
                comboBox1.Items.Clear();
                string[] puertos = SerialPort.GetPortNames();
                comboBox1.Items.AddRange(puertos);
                if (comboBox1.Items.Count > 0)
                {
                    comboBox1.SelectedIndex = 0;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (serialPort1.IsOpen)
                {
                    timer1.Enabled = false;
                    serialPort1.Close();
                    comboBox1.Enabled = true;
                    textBox1.Enabled = true;
                    textBox2.Enabled = true;
                    button2.Enabled = true;
                    button1.Text = "Conectar";
                }
                else
                {
                    timer1.Interval = Convert.ToInt32(textBox1.Text);
                    serialPort1.PortName = comboBox1.Text;
                    serialPort1.BaudRate = 921600;
                    serialPort1.DataBits = 8;
                    serialPort1.Parity = Parity.None;
                    serialPort1.StopBits = StopBits.One;
                    serialPort1.Handshake = Handshake.None;
                    serialPort1.Encoding = Encoding.ASCII;
                    serialPort1.ReadTimeout = 100;
                    serialPort1.WriteTimeout = 100;
                    serialPort1.Open();
                    serialPort1.DiscardInBuffer();
                    timer1.Enabled = true;
                    comboBox1.Enabled = false;
                    textBox1.Enabled = false;
                    textBox2.Enabled = false;
                    button2.Enabled = false;
                    button1.Text = "Desconectar";
                    //clearGraficos(getGraficos());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private double[] getValores(string datos, double[] ganancia, double[] offset)
        
        {

            string[] parseados = datos.Split(new char[] { '\t' }, StringSplitOptions.RemoveEmptyEntries);
            double[] ret = new double[Nvariables];
            int[] mascaras = new int[4] { 0x00FFFFFF, -1, -1, -1 };
            for (int i = 0; i < ret.Length; i++)
            {
                ret[i] = Convert.ToDouble(Convert.ToInt32(parseados[i], 16) & mascaras[i]) * ganancia[i] + offset[i];
            }
            int dbg = (Convert.ToInt32(parseados[0], 16) >> 24)&0xFF;
            listView1.Items[Nvariables].SubItems[1].Text = ((dbg & 0x80) != 0) ? "Pulsos" : "Fluctuación";
            listView1.Items[Nvariables+1].SubItems[1].Text = "0x" + dbg.ToString("X2");
            return ret;
        }

        private void escribirEnTabla(double[] valores)
        {
            for (int i = 0; i < Nvariables; i++)
            {
                if (i < Nvariables - 1)
                {
                    listView1.Items[i].SubItems[1].Text = Convert.ToString(valores[i]);
                }
                else
                {
                    listView1.Items[i].SubItems[1].Text = valores[i].ToString("G3");
                }
            }
        }

        private void dibujar(Chart g, double dato, int ventana)
        {
            if (g.Series[0].Points.Count >= ventana)
            {
                g.Series[0].Points.RemoveAt(0);
            }
            g.Series[0].Points.AddY(dato);
            g.Series[0].Points.Invalidate();
            g.ChartAreas[0].RecalculateAxesScale();
            g.Update();
        }

        private void mostrarTodo(Chart[] graficos, double[] valores)
        {
            int ventana = Convert.ToInt32(textBox2.Text);
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < Nvariables; j++)
                {
                    dibujar(graficos[j + (i*Nvariables)], valores[j], ventana);
                }
            }
        }

        private void ponerNombres(Chart[] graficos, string[] nombres)
        {
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < Nvariables; j++)
                {
                    graficos[j + (i * Nvariables)].ChartAreas[0].AxisY.Title = nombres[j];
                }
            }
        }

        private double compensar_tiempo_muerto(double valor)
        {
            double tiempo_muerto;
            if (!double.TryParse(textBox3.Text, out tiempo_muerto))
            {
                tiempo_muerto = 0.0;
            }
            tiempo_muerto = tiempo_muerto * 1e-9;
            return valor / (1 - tiempo_muerto * valor);
        }

        private void EscribirValores(double valor, long N)
        {
            label10.Text = Math.Round(valor, 0).ToString();
            double conteo_sin_compensar = valor / N * 10.0;
            if(checkBox2.Checked) label11.Text = Math.Round(compensar_tiempo_muerto(conteo_sin_compensar)).ToString("0");
            else label11.Text = Math.Round(conteo_sin_compensar).ToString("0");
        }

        private void GraficarPulsos(double valor, long N, bool cps)
        {
            Chart[] graficos = getGraficos();

            double conteo = valor;
            if (cps)
            {
                conteo = conteo / (N * 0.1);
            }
            if(checkBox2.Checked) { dibujar(graficos[4], compensar_tiempo_muerto(conteo), Convert.ToInt32(textBox2.Text)); }
            else { dibujar(graficos[4],conteo, Convert.ToInt32(textBox2.Text)); }
            label13.Text = ((conteo-compensar_tiempo_muerto(conteo))/compensar_tiempo_muerto(conteo)).ToString("0.0%");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string patronvalido = "(0[xX][0-9a-fA-F]{8}\t){3}(0[xX][0-9a-fA-F]{8})";
            System.Text.RegularExpressions.Regex rgx = new System.Text.RegularExpressions.Regex(patronvalido);
            if (serialPort1.IsOpen)
            {
                int bytesaleer = serialPort1.BytesToRead;
                if (bytesaleer > LenStringDato)
                {
                    byte[] bytes = new byte[bytesaleer];
                    serialPort1.Read(bytes, 0, bytes.Length);
                    string strdata = Encoding.ASCII.GetString(bytes);
                    string[] parseados = strdata.Split(new char[]{'\n'},StringSplitOptions.RemoveEmptyEntries);
                    System.Text.RegularExpressions.Match match;
                    for (int i = 0; i < parseados.Length; i++)
                    {
                        match = rgx.Match(parseados[i]);
                        if (match.Success)
                        {                            
                            double[] valores = getValores(match.Value, new double[] { 1.0, 1.0, 1.0, 1.0 }, new double[] { 0.0, 0.0, 0.0, -32768.0 });
                            Promediado = Promediado + valores[0];
                            faltan = faltan + 0.1;
                            label7.Text = Math.Round(faltan, 1).ToString("0.0");
                            if (++Promediando >= NumeroAPromediar)
                            {
                                //escribirEnTabla(valores);
                                //mostrarTodo(getGraficos(), valores);
                                GraficarPulsos(Promediado, NumeroAPromediar, checkBox1.Checked);
                                EscribirValores(Promediado, NumeroAPromediar);
                                if (Registrar)
                                {
                                    try
                                    {
                                        StreamWriter fo = new StreamWriter(saveFileDialog1.FileName, true);
                                        fo.WriteLine(string.Format("{0};{1};{2}", obtenerMarcaDeTiempo(), Convert.ToInt64(Promediado), Convert.ToInt64(NumeroAPromediar)));
                                        fo.Close();
                                    }
                                    catch
                                    {
                                        registrarToolStripMenuItem.Checked = false;
                                        Registrar = false;
                                        this.Text = Nombre;
                                    }
                                }
                                button4_Click(sender, e);
                                break;
                            }
                        }
                    }

                }
            }
        }

        private string obtenerMarcaDeTiempo()
        {           
            return DateTime.Now.ToString("yyyy;MM;dd;HH;mm;ss");
        }
        private void limpiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clearGraficos(getGraficos());
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Enabled = false;
                serialPort1.Close();
            }
        }

        private void registrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (registrarToolStripMenuItem.Text == "R&egistrar...")
            {
                saveFileDialog1.Filter = "Archivos de log (*.log)|*.log";
                if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    StreamWriter fo = new StreamWriter(saveFileDialog1.FileName,false);
                    fo.Close();
                    Registrar = true;
                    registrarToolStripMenuItem.Text = "D&etener Registro";
                    this.Text = Nombre + " (Registrando)";
                }
                
            }
            else
            {
                Registrar = false;
                registrarToolStripMenuItem.Text = "R&egistrar...";
                this.Text = Nombre;
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Promediado = 0.0;
            Promediando = 0;
            faltan = 0.0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double valor = 0.0;
            string separador = System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
            string numero = comboBox2.Text;
            numero = numero.Replace(",", separador);
            numero = numero.Replace(".", separador);
            if (Double.TryParse(numero, out valor))
            {
                valor = Math.Round(valor * 10.0, 0);
                int N = Convert.ToInt32(valor);
                NumeroAPromediar = N;
                button4_Click(sender, e);
                label6.Text = (valor / 10.0).ToString("0.0");
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            limpiarToolStripMenuItem_Click(sender, e);
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }
    }
}
